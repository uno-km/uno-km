"""Generated contracts package."""
